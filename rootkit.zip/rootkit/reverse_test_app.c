#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char data[513] = "No data";

void insert_word(char *word, unsigned int n)
{
  int i, c;
  char tmpword[512+1];
  for (i = strlen(word)-1, c = 0; i >= 0; i--, c++) {
      tmpword[c] = word[i];
  }
  tmpword[strlen(word)] = '\0';
  if (n == 0) {
      memset(data, 0, sizeof data);
      strcpy(data, tmpword);
  } else {
      data[strlen(data)] = ' ';
      data[strlen(data)+1] = '\0';
      strcat(data, tmpword);
  }
}

void reverse(char *tmpdata)
{
  int i, c;
  unsigned int n = 0;
  char word[512+1];
  for (i = strlen(tmpdata)-1, c = 0; i >= 0; i--, c++) {
      if (tmpdata[i] == ' ') {
          word[c] = '\0';
          insert_word(word, n);
          n += 1;
          c = -1;
      } else
          word[c] = tmpdata[i];
      
  }
  word[c] = '\0';
  insert_word(word, n);
  data[strlen(tmpdata)] = '\0';
}

int main(int argc, char **argv)
{
  if (argc < 2) {
      printf("Usage: %s <string>\n", argv[0]);
      exit(1);
  }

  printf("Before: %s\n", data);
  reverse(argv[1]);
  printf("After: %s\n", data);
}

